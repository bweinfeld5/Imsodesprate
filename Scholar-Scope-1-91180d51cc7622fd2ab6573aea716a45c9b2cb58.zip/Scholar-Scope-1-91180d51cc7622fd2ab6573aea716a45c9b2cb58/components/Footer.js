const Footer = () => (
  <footer>
    <p>Footer content here</p>
  </footer>
);

export default Footer;
